#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "RW_lock.h"


void RW_lock_init(RW_lock_t *lock)
{ 
}

void RW_read_lock(RW_lock_t *lock)
{ 
}

void RW_read_unlock(RW_lock_t *lock)
{  
}

void RW_write_lock(RW_lock_t *lock)
{  pthread_mutex_lock(&(lock->g));
}

void RW_write_unlock(RW_lock_t *lock)
{ 
}


