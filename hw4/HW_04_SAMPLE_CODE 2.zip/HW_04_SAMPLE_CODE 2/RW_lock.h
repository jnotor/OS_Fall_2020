#include <pthread.h>

// This is a header file for a Read/Right Lock Library.  Your C code for
// homework 4 SHOULD access your routines using these exact function 
// prototypes

typedef struct RW_lock_s
      { 
      } RW_lock_t;


void RW_lock_init(RW_lock_t *lock);
    /* This routine should be called on a pointer to a struct variable of RW_lock_t
       to initialize it and ready it for use. */

void RW_read_lock(RW_lock_t *lock);
    /* This routine should be called at the beginning of a READER critical section */

void RW_read_unlock(RW_lock_t *lock);
    /* This routine should be called at the end of a READER critical section */

void RW_write_lock(RW_lock_t *lock);
    /* This routine should be called at the beginning of a WRITER critical section */

void RW_write_unlock(RW_lock_t *lock);
    /* This routine should be called at the end of a WRITER critical section */

